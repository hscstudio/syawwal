<?php

namespace backend\tests\unit;

class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@backend/tests/unit/_config.php';
}
