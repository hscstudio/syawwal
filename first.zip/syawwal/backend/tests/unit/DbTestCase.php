<?php

namespace backend\tests\unit;

class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@backend/tests/unit/_config.php';
}
