JQuery JavaScript Library
==================

This repository is maintained for composer package support purpose.

For the actual repository visit: 

http://www.jquery.com

https://github.com/jquery/jquery
