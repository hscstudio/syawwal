Yii Framework 2 Change Log
==========================

2.0.0 beta under development
----------------------------
- Bug #2495: Fixed avoid duplicates of _pjax parameter (tof06)
- Bug #2692: Fixed Pjax/GridView and back button (klevron, tof06, tonydspaniard)